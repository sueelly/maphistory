package com.changui0.will_it_rain;

public class Point2D {
    public double x, y;

    public Point2D(double x_, double y_) {
        x = x_;
        y = y_;
    }
}
